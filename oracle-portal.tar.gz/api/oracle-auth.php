<?php
// CENTRO MÉDICO UNIVERSAL - ORACLE AUTHENTICATION API
// Login System Using ORACLE MySQL Database
// Authenticates against ORACLE users table

require_once 'oracle-config.php';

session_start();

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    // LOGIN - ORACLE DATABASE AUTHENTICATION
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['username']) || !isset($data['password'])) {
        sendError('Username and password are required');
    }
    
    $username = $data['username'];
    $password = $data['password'];
    
    $conn = getOracleDBConnection();
    
    // Query ORACLE users table
    $stmt = $conn->prepare("SELECT id, username, password, full_name, role, email FROM users WHERE username = ?");
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        sendError('Invalid credentials - User not found in ORACLE database', 401);
    }
    
    $user = $result->fetch_assoc();
    
    // Verify password against ORACLE stored password
    $passwordValid = false;
    
    // Check default ORACLE admin passwords
    if ($password === 'Admin@2025' && in_array($username, ['mcastillo', 'admin'])) {
        $passwordValid = true;
    } elseif (password_verify($password, $user['password'])) {
        $passwordValid = true;
    }
    
    if (!$passwordValid) {
        sendError('Invalid credentials - Password does not match ORACLE record', 401);
    }
    
    // Create session with ORACLE user data
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['data_source'] = 'ORACLE_MYSQL';
    
    unset($user['password']);
    
    sendSuccess($user, 'Login successful - Authenticated with ORACLE database');
    
} elseif ($method === 'GET') {
    // CHECK ORACLE AUTH STATUS
    if (!isset($_SESSION['user_id'])) {
        sendError('Not authenticated with ORACLE', 401);
    }
    
    sendSuccess([
        'user_id' => $_SESSION['user_id'],
        'username' => $_SESSION['username'],
        'full_name' => $_SESSION['full_name'],
        'role' => $_SESSION['role'],
        'email' => $_SESSION['email'],
        'data_source' => 'ORACLE_MYSQL'
    ]);
    
} elseif ($method === 'DELETE') {
    // LOGOUT FROM ORACLE SESSION
    session_destroy();
    sendSuccess([], 'Logged out from ORACLE system');
}
?>
